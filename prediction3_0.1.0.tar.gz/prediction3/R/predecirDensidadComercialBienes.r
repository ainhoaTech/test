#' @title test
#'
#' @description
#'
#' @param input
#'
#' @return
#'
#' @examples
#'
#' @export predecirDensidadComercialBienes
#'
##El valor input debe estar en formato JSON
##El output debe estar en el mismo formato JSON

predecirDensidadComercialBienes <- function(input){
  library(magrittr)
  library(stringr)
  library(jsonlite)
  library(rJava)
  library(RWeka)

  ##índice de las variables con las que han creado el modelo

  index<-which(prediction2::matrix[,13]==1)
  ##instancia base
  Name<-colnames(data)[index]

  ##crear data.frame
  instancia<-data.frame(Name,Value = c(rep(0,length(Name))),stringsAsFactors=FALSE)
  instancia<-t(instancia)
  colnames(instancia)<-instancia[1,]
  instancia<-instancia%>%as.data.frame()
  instancia<-instancia[-1,]
  row.names(instancia)<-NULL

  ##Leer el archivo desde JSON a un dataframe
  data2<-fromJSON(input)


  ##?ndices de las columnas donde est?n las variables predictivas
  index2<-which(prediction2::matrix_v2[index,13]==1)


  ##Meter los nuevos valores en las posiciones adecuadas
  instancia[,index2]<-data2




  resultado<- stats::predict(indicador6, instancia)%>%as.data.frame()

  colnames(resultado)<-"resultado"
  ##Devolver predicci?n formato JSON
  resultado<-toJSON(resultado)
  returnValue (resultado)
}
