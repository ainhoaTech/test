#' @title test
#'
#' @description
#'
#' @param input
#'
#' @return
#'
#' @examples
#'
#' @export predecirAccidentes
#'
##El valor input debe estar en formato JSON
##El output debe estar en el mismo formato JSON

predecirAccidentes <- function(input){
  library(magrittr)
  library(stringr)
  library(jsonlite)


  #To ignore the warnings during usage
  options(warn=-1)
  options("getSymbols.warning4.0"=FALSE)

  ##instancia base
  Name<-c( "Antigüedad.media.de.las.viviendas.familiares"
           , "Consumo.eléctrico.anual.del.municipio.por.habitante."
           , "Consumo.eléctrico.anual.industrial.por.habitante"
           , "Consumo.eléctrico.anual.no.industrial.por.habitante"
           , "Porcentaje.de.contratos.indefinidos.sobre.el.total.de.contratos"
           , "Porcentaje.de.contratos.indefinidos.de.personas.menores.de.30.sobre.el.total.de.contratos.indefinidos"
           , "Porcentaje.de.contratos.indefinidos.de.mujeres.sobre.el.total"
           ,"Porcentaje.de.contratos.indefinidos.de.personas.de.más.de.45.sobre.el.total.de.contratos.indefinidos"
           , "Número.de.contratos.registrados.por.cada.1.000.habitantes"
           ,"Demanda.total.de.agua.por.habitante.y.día"
           ,"Densidad.comercial.de.bienes.ocasionales.por.1.000.habitantes"
           ,"Densidad.comercial.minorista.por.cada.1.000.habitantes"
           , "Densidad.de.viviendas.en.suelo.residencial"
           , "Densidad.poblacional"
           , "Deuda.viva.del.Ayuntamiento.por.habitante"
           , "Número.de.días.con.calidad.del.aire.buena.o.admisible"
           , "Dotación.policial.local.por.cada.1.000.habitantes"
           , "Porcentaje.de.viviendas.familiares.con.instalación.de.gas.por.tubería"
           , "Porcentaje.del.empleo.generado.por.las.microempresas"
           , "Número.de.establecimientos.de.hostelería.y.restauración.por.1.000.habitantes"
           , "Número.de.farmacias.por.cada.10.000.habitantes"
           , "Número.de.gasolineras.por.cada.10.000.habitantes"
           , "Gasto.liquidado.del.Ayuntamiento.por.habitante."
           ,"Grado.de.ocupación.de.los.centros.de.día.3ª.edad.y.personas.con.discapacidad."
           , "Grado.de.ocupación.de.los.centros.residenciales.3ª.edad.y.personas.con.discapacidad."
           , "Porcentaje.de.hombres.parados.de.larga.duración.de.16.a.24.años"
           , "Número.de.hombres.parados.por.cada.100.hombres.de.16.a.64.años"
           , "Índice.de.delitos"
           , "Índice.de.dependencia.demográfica."
           , "Índice.de.envejecimiento"
           , "Índice.de.infancia"
           , "Índice.de.rotación.contractual"
           , "Índice.de.rotación.contractual.hombres"
           , "Índice.de.rotación.contractual.mujeres"
           , "Índice.de.sobreenvejecimiento.Hombres"
           , "Índice.de.sobreenvejecimiento.Mujeres"
           , "Índice.de.sobreenvejecimiento"
           , "Ingresos.municipales.por.operaciones.corrientes"
           , "Inversión.neta.del.Ayuntamiento.por.habitante."
           , "Licencias.de.vivienda.nueva.concedidas.en.el.último.quinquenio.por.cada.1.000.habitantes."
           , "Porcentaje.de.mujeres.paradas.de.larga.duración.sobre.el.total.de.mujeres.de.16.a.64.años"
           , "Porcentaje.de.mujeres.paradas.sobre.el.total.de.mujeres.de.16.a.64.años"
           , "Oficinas.bancarias.por.cada.10.000.habitantes."
           , "Oficinas.de.Correos.por.cada.10.000.habitantes."
           , "Parque.de.turismos"
           , "Parque.de.vehículos"
           , "Peatones.atropellados.por.cada.100.000.habitantes."
           , "Personas.beneficiarias.de.Renta.de.Garantía.de.Ingresos.por.cada.1.000.habitantes"
           , "PIB.municipal.per.cápita."
           , "PIB.municipal.per.cápita.Base.CAE.100."
           , "PIB.municipal.por.persona.ocupada."
           , "PIB.municipal.por.persona.ocupada.Base.CAE.100."
           , "Plazas.de.alojamiento.turístico.por.cada.1.000.habitantes"
           , "Plazas.en.centros.de.día.para.la.3ª.edad"
           , "Plazas.en.centros.de.día.para.personas.discapacitadas.por.cada.1.000.habitantes."
           , "Plazas.en.centros.residenciales.para.la.3ª.edad.por.cada.1.000.habitantes"
           , "Plazas.en.centros.residenciales.para.personas.discapacitadas.por.cada.1.000.habitantes"
           , "Población.contratada.por.cada.1.000.habitantes"
           , "Porcentaje.de.parados.sobre.el.total.de.la.población.de.45.a.64.años"
           , "Porcentaje.de.personas.con.al.menos.Estudios.Secundarios"
           , "Porcentaje.de.la.población.con.estudios.profesionales"
           , "Porcentaje.de.la.población.con.estudios.universitarios"
           , "Porcentaje.de.hombres.sobre.el.total.de.la.población.extranjera"
           , "Porcentaje.de.mujeres.sobre.el.total.de.la.población.extranjera"
           , "Porcentaje.de.la.población.extranjera.sobre.el.total"
           , "Porcentaje.de.población.inmigrante.de.fuera.de.la.UE.15.sobre.el.total.de.la.población.extranjera."
           , "Porcentaje.de.población.inmigrante.de.fuera.de.la.UE.sobre.el.total.de.la.población.extranjera"
           , "Porcentaje.de.parados.de.larga.duración.sobre.el.total.personas.de.16.a.64"
           , "Porcentaje.de.parados.sobre.el.total.personas.de.16.a.64"
           , "Población.total"
           , "Porcentaje.de.establecimientos.del.sector.construcción.sobre.el.total."
           , "Porcentaje.de.establecimientos.del.sector.industrial.sobre.el.total."
           , "Porcentaje.de.establecimientos.del.sector.primario.sobre.el.total."
           , "Porcentaje.de.establecimientos.del.sector.servicios.sobre.el.total."
           , "Potencia.eólica.instalada.por.10.000.habitantes"
           , "Potencia.fotovoltaica.instalada.por.10.000.habitantes"
           , "Potencia.hidráulica.instalada.por.10.000.habitantes"
           , "Presion.fiscal.municipal.por.habitante"
           , "Recaudación.impositiva.del.Ayuntamiento.por.habitante."
           , "Renta.familiar.total."
           , "Renta.personal.derivada.del.trabajo.renta.personal.total."
           , "Renta.personal.derivada.del.trabajo.renta.personal.total.Hombres"
           , "Renta.personal.derivada.del.trabajo.renta.personal.total.Mujeres"
           , "Renta.personal.disponible.Hombres."
           , "Renta.personal.disponible.Mujeres."
           , "Renta.personal.disponible."
           , "Renta.personal.disponible.Base.CAE.100."
           , "Renta.personal.total.Hombres."
           , "Renta.personal.total.Mujeres."
           , "Renta.personal.total."
           , "Renta.personal.total.Base.CAE.100."
           , "Saldo.migratorio.externo."
           , "Saldo.neto.de.establecimientos.por.cada.1.000.habitantes"
           , "Solicitud.de.vivienda.por.cada.1.000.habitantes"
           , "Suelo.urbano."
           , "Superficie.comercial.minorista.por.habitante"
           , "Porcentaje.de.superficie.de.suelo.artificializado."
           , "Porcentaje.de.superficie.destinada.a.carreteras"
           , "Porcentaje.de.superficie.destinada.a.infraestructuras.de.transporte.y.comunicaciones"
           , "Superficie.media.de.las.viviendas.familiares"
           , "Porcentaje.de.superficie.de.especial.protección"
           , "Porcentaje.de.superficie.residencial.urbanizable.sobre.el.total.residencial"
           , "Superficie.solar.térmica.instalada.por.cada.10.000.habitantes."
           , "Tamaño.medio.de.los.establecimientos.industriales"
           , "Tasa.bruta.de.natalidad."
           , "Porcentaje.de.personal.administrativo.afiliado.a.la.SS.sobre.el.total.de.afiliados."
           , "Porcentaje.de.personal.directivo.afiliado.a.la.SS.sobre.el.total.de.afiliados"
           , "Porcentaje.de.oficiales.de.producción.afiliados.a.la.SS.sobre.el.total.de.afiliados"
           ,"Porcentaje.de.personal.no.cualificado.y.aprendices.afiliados.a.la.SS.sobre.el.total.de.afiliados"
           , "Porcentaje.de.personas.afiliadas.del.sector.Construcción.sobre.el.total"
           , "Porcentaje.de.personas.afiliadas.del.sector.industrial.sobre.el.total"
           , "Porcentaje.de.personas.afiliadas.del.sector.Primario.sobre.el.total"
           , "Porcentaje.de.personas.afiliadas.del.sector.Servicios.sobre.el.total"
           , "Tasa.de.afiliación.a.la.Seguridad.Social.por.municipio.de.residencia"
           , "Tasa.de.afiliación.a.la.Seguridad.Social.de.los.hombres.por.municipio.de.residencia."
           , "Tasa.de.afiliación.a.la.Seguridad.Social.de.las.mujeres.por.municipio.de.residencia."
           , "Tasa.de.afiliación.a.la.seguridad.social.por.municipio.de.residencia.población.16.24.años"
           , "Tasa.de.afiliación.a.la.Seguridad.Social.por.municipio.de.trabajo"
           , "Tasa.de.afiliación.a.la.Seguridad.Social.de.los.hombres.por.municipio.de.trabajo"
           , "Tasa.de.afiliación.a.la.Seguridad.Social.de.las.mujeres.por.municipio.de.trabajo"
           , "Tasa.de.creación.de.nuevos.establecimientos"
           , "Tasa.de.crecimiento.acumulativo.anual.del.PIB.en.el.último.periodo."
           , "Tasa.de.crecimiento.vegetativo."
           , "Tasa.media.de.crecimiento.acumulativo.anual.de.la.renta.personal.en.el.último.periodo.Hombres"
           , "Tasa.media.de.crecimiento.acumulativo.anual.de.la.renta.personal.en.el.último.periodo.Mujeres"
           , "Tasa.media.de.crecimiento.acumulativo.anual.de.la.renta.personal.total.en.el.último.periodo."
           , "Teléfonos.públicos.por.cada.1.500.habitantes."
           , "Unidades.convivenciales.perceptoras.de.Ayudas.de.Emergencia.Social.por.cada.1.000.habitantes"
           , "Unidades.de.educación.infantil.por.cada.100.habitantes.de.0.a.2.años"
           , "Variación.de.la.población.en.la.última.década."
           , "Variación.interanual.de.la.población."
           , "Variación.interanual.en.la.cifra.de.empleo."
           , "Viviendas.adjudicadas.en.el.último.trienio.por.cada.100.solicitudes"
           , "Porcentaje.de.viviendas.con.certificado.de.eficiencia.energética."
           , "Porcentaje.de.viviendas.familiares.con.más.de.50.años.de.antigüedad"
           , "Viviendas.protegidas.VPO.adjudicadas.en.el.último.quinquenio.por.cada.1.000.habitantes"
           , "Viviendas.protegidas.VPO.terminadas.en.el.último.quinqueniopor.cada.1.000.habitantes"
           , "Volúmenes.de.las.bibliotecas.de.acceso.público.por.habitante"
           ,"Porcentaje.de.mujeres"
           ,"Porcentaje.de.hombres"
           ,"Número.de.centros"
           ,"Número.de.residencias"
           ,"Número.de.defunciones"
           , "Saldo.migratorio.total"
           ,"Saldo.migratorio.externo"
           , "Saldo.migratorio.interno"
           , "Valor.añadido.bruto"
           ,"Gastos_por_habitante"
           ,"Ingresos_por_habitante"
           ,"Presupuesto_Administración_general"
           ,"Presupuesto_Bienestar_comunitario"
           ,"Presupuesto_Cultura"
           ,"Presupuesto_Deuda_pública"
           , "Presupuesto_Educación"
           , "Presupuesto_Infraestructuras_básicas_y_tansportes"
           ,"Presupuesto_Otros"
           ,"Presupuesto_Producción_de_bienes_de_carácter_económico"
           ,"Presupuesto_Producción_de_bienes_públicos_de_carácter_social"
           ,"Presupuesto_Seguridad_protección_y_promoción_social"
           , "Presupuesto_Servicios_de_carácter_general"
           ,"Presupuesto_Vivienda_y_urbanismo"
           ,"Presupuesto_Sanidad"
           , "Presupuesto_Órganos_de_gobierno")
  instancia<-data.frame(Name,Value = c(rep(0,length(Name))),stringsAsFactors=FALSE)
  instancia<-t(instancia)
  colnames(instancia)<-instancia[1,]
  instancia<-instancia%>%as.data.frame()
  instancia<-instancia[-1,]
  row.names(instancia)<-NULL

  ##Leer el archivo desde JSON a un dataframe
  data<-fromJSON(input)


  ##?ndices de las columnas donde est?n las variables predictivas
  index2<-c(4,11,3,14,33,35,20,22,43,70,72,63,69,66,98,156,159,94,95,103,117,118)


  ##Meter los nuevos valores en las posiciones adecuadas
  instancia[,index2]<-data
  
  a<-model
  library(rJava)
  library(RWeka)

  resultado<- stats::predict(a, instancia)%>%as.data.frame()

  colnames(resultado)<-"resultado"
  ##Devolver predicci?n formato JSON
  resultado<-toJSON(resultado)
  print(resultado)

}

