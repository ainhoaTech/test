#' @title test
#'
#' @description
#'
#' @param input
#'
#' @return
#'
#' @examples
#'
#' @export predecirParqueTurismo
#'
##El valor input debe estar en formato JSON
##El output debe estar en el mismo formato JSON

predecirParqueTurismo<- function(input){
  library(magrittr)
  library(stringr)
  library(jsonlite)
  library(rJava)
  library(RWeka)

  ##índice de las variables con las que han creado el modelo

  index<-which(prediction::matrix[,47]==1)
  ##instancia base
  instancia<-prediction::data[1,index]

  ##Leer el archivo desde JSON a un dataframe
  data2<-fromJSON(input)
  data2<-as.data.frame(data2,stringsAsFactors=F)

  ##?ndices de las columnas donde est?n las variables predictivas
  index2<-which(prediction::matrix_v2[index,14]==1)


  ##Meter los nuevos valores en las posiciones adecuadas
  instancia[,index2]<-data2




  resultado<- stats::predict(prediction::indicador13, instancia)%>%as.data.frame()

  colnames(resultado)<-"resultado"
  ##Devolver predicci?n formato JSON
  resultado<-toJSON(resultado)
  returnValue (resultado)
}
